-- Stored Procedure to Return a List of All the Customers (READ)
USE AsgmtDB;
GO
 
CREATE OR ALTER PROCEDURE dbo.GetCustomers -- CREATE PROCEDURE
AS
BEGIN
	SELECT CustID, CustName, CustEmail, CustContactNo, CustAddress, DateCreated
	FROM dbo.Customers
END;
 
-- Run to test the SP
EXEC dbo.GetCustomers;

--------------------------------------------------------------------------
--                   Separation of Statement Execution                   |
--------------------------------------------------------------------------

-- Stored Procedure to Insert a Single Customer (CREATE)
USE AsgmtDB;
GO

CREATE OR ALTER PROCEDURE dbo.InsCustomer
      @CustName			varchar(100), -- input parameters
	  @CustEmail 		varchar(80),
	  @CustContactNo 	varchar(20),
      @CustAddress   	varchar(80)
AS
BEGIN
      INSERT INTO [dbo].[Customers]
               ([CustName]
               ,[CustEmail]
               ,[CustContactNo]
               ,[CustAddress]
			   ,[DateCreated])
          VALUES
               (@CustName
               ,@CustEmail
               ,@CustContactNo
			   ,@CustAddress
               ,getdate())
END;
 
--To Execute Stored Procedure you would run the following SQL code:
EXEC dbo.InsCustomer
      @CustName = 'Test SP Company',
	  @CustEmail = 'testsp@gmail.com',
	  @CustContactNo = '0198765432',
      @CustAddress = 'Jalan SP';
 
SELECT * FROM dbo.Customers;

--------------------------------------------------------------------------
--                   Separation of Statement Execution                   |
--------------------------------------------------------------------------

-- Stored Procedure to Update a Single Customer (UPDATE)
USE AsgmtDB;
GO

CREATE OR ALTER PROCEDURE dbo.UpdCustomer
      @CustID        int          = null,
      @CustName      varchar(100) = null,
	  @CustEmail 	 varchar(80) = null,
	  @CustContactNo varchar(20) = null,
      @CustAddress   varchar(80) = null
AS
BEGIN
      UPDATE dbo.Customers
      SET CustName      = ISNULL(@CustName, CustName)
	     ,CustEmail     = ISNULL(@CustEmail, CustEmail)
	     ,CustContactNo = ISNULL(@CustContactNo, CustContactNo)
         ,CustAddress   = ISNULL(@CustAddress, CustAddress)
      WHERE CustID = @CustID
END;
 
--To Execute Stored Procedure you would run the following SQL code:
EXEC dbo.UpdCustomer
      @CustID        = 305,
	  @CustEmail     = 'testsp@gmail.com',
      @CustName      = 'Test Update',
      @CustAddress   = null,
      @CustContactNo = '123456'
 
SELECT * FROM dbo.Customers;

--------------------------------------------------------------------------
--                   Separation of Statement Execution                   |
--------------------------------------------------------------------------

-- Stored Procedure to Delete a Single Customer based on its ID (DELETE)
USE AsgmtDB;
GO

CREATE OR ALTER PROCEDURE dbo.DelCustomer
      @CustID int
AS
BEGIN
      DELETE FROM dbo.Customers
      WHERE CustID = @CustID
END;
 
--To Execute Stored Procedure you would run the following SQL code:
EXEC dbo.DelCustomer
      @CustID = 3;
 
SELECT * FROM dbo.Customers;

--------------------------------------------------------------------------
--                   Separation of Statement Execution                   |
--------------------------------------------------------------------------

-- Stored Procedure to Return a Single Customer Based on an ID
USE AsgmtDB;
GO

CREATE OR ALTER PROCEDURE dbo.GetCustomer
   @CustID int  -- input parameter
AS
BEGIN
      SELECT [CustID]
            ,[CustName]
            ,[CustEmail]
            ,[CustContactNo]
			,[CustAddress]
            ,[DateCreated]
      FROM [dbo].[Customers]
      WHERE CustID = @CustID
END;
 
--To Execute Stored Procedure you would run the following SQL code:
EXEC dbo.GetCustomer @CustID = 305;