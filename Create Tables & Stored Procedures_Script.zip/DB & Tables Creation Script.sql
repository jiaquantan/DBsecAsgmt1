/* 	Create the database */
DROP DATABASE IF EXISTS AsgmtDB
GO
CREATE DATABASE AsgmtDB;
GO

/* Create the tables with data */
USE AsgmtDB;
GO

-- Create Suppliers table
DROP TABLE IF EXISTS Suppliers;
GO
CREATE TABLE Suppliers
( 
	SupplierID INT PRIMARY KEY IDENTITY (100,1),
	SupplierName NVARCHAR(100) NOT NULL,
	SupplierContactNo NVARCHAR(20) NOT NULL,
	Address NVARCHAR(80) NOT NULL,
	SupplierEmail NVARCHAR(80) NOT NULL,
	DateCreated DATETIME NOT NULL DEFAULT getdate()
);

INSERT INTO Suppliers (SupplierName, SupplierContactNo, Address, SupplierEmail) VALUES
('MMU Tech Sdn Bhd', '03-8312 5000', 'Jalan Multimedia, Cyberjaya, Sepang Selangor', 'mmu@edu.my'),
('Cyber Tech Sdn Bhd', '03-8312 5001', 'Jalan Silikon, Cyberjaya, Sepang, Selangor', 'cybertech@gmail.com'),
('MTS Sdn Bhd', '03-8312 5002', 'Jalan Sungai Merab, Kajang, Selangor', 'mts@gmail.com'),
('Alpha Sdn Bhd', '03-8312 5003', 'Jalan Ampang, Kuala Lumpur', 'alpha@gmail.com'),
('Beta Logistics Sdn Bhd', '03-8312 5004', 'Persiaran TRX, Tun Razak Exchange, Kuala Lumpur', 'betalogistics@gmail.com');

SELECT * FROM Suppliers;
-- EXEC sp_help Suppliers;


-- Create Employees table
DROP TABLE IF EXISTS Employees;
GO

CREATE TABLE Employees
 (
	EmpID INT PRIMARY KEY IDENTITY (200,1),
	EmpName NVARCHAR(100) NOT NULL,
	EmpEmail NVARCHAR(80) NOT NULL,
	Department NVARCHAR(50) NOT NULL,
	JobTitle NVARCHAR(50) NOT NULL,
	Salary INT NOT NULL,
	DateCreated DATETIME NOT NULL DEFAULT getdate()
);

INSERT INTO Employees (EmpName, EmpEmail, Department, JobTitle, Salary) VALUES
('Thomas Shelby', 'thomas.shelby@gmail.com', 'Executive', 'CEO', '88000'),
('John Doe', 'john.doe@gmail.com', 'IT', 'System Administrator', '20000'),
('Jane Smith', 'jane.smith@gmail.com', 'Finance', 'Finance Manager', '15000'),
('Alice Johnson', 'alice.johnson@gmail.com', 'HR', 'HR Manager', '13000'),
('Frank Wilson', 'frank.wilson@gmail.com', 'HR', 'Recruiter', '7000'),
('Jack Walker', 'jack.walker@gmail.com', 'Sales', 'Sales Manager', '6000'),
('Eve Davis', 'eve.davis@gmail.com', 'Sales', 'Sales Executive', '5500'),
('Carol White', 'carol.white@gmail.com', 'Sales', 'Sales Executive', '5500'),
('Joe Biden', 'joe.biden@gmail.com', 'Sales', 'Sales Consultant', '4000'),
('Tony Stark', 'tony.stark@gmail.com', 'Sales', 'Sales Consultant', '4000');

SELECT * FROM Employees;
-- EXEC sp_help Employees;


-- Create Customers table
DROP TABLE IF EXISTS Customers;
GO

 CREATE TABLE Customers
(
	CustID INT CONSTRAINT PK_Customers PRIMARY KEY IDENTITY (300,1),
	CustName NVARCHAR(100) NOT NULL,
	CustEmail NVARCHAR(80) NOT NULL,
	CustContactNo NVARCHAR(20) NOT NULL,
	CustAddress NVARCHAR(80) NOT NULL,
	DateCreated DATETIME NOT NULL CONSTRAINT DF_Customers_DateCreated DEFAULT getdate()
);

INSERT INTO Customers (CustName, CustEmail, CustContactNo, CustAddress) VALUES
('Joe Blogs', 'joe@gmail.com', '0123456780', 'Jalan KSB 11A, Melaka'),
('Bryan Doe', 'bryan@gmail.com', '0123456781', 'Mid Valley City, Kuala Lumpur'),
('James Smith', 'james@gmail.com', '0123456782', 'Ioi City Mall, Ioi Resort, Putrajaya'),
('Eddy Jones', 'eddy@gmail.com', '0123456783', 'Jalan Hang Jebat, Kuala Lumpur'),
('Indiana Jones', 'indiana@gmail.com', '0123456784', 'Jalan Ipoh, Kuala Lumpur');

SELECT * FROM Customers;
-- EXEC sp_help Customers;


-- Create CreditCards table
DROP TABLE IF EXISTS CreditCards;
GO

CREATE TABLE CreditCards
(
	CardID INT CONSTRAINT PK_CreditCards PRIMARY KEY IDENTITY (1,1),
	CardType NVARCHAR(50) NOT NULL,
	CardNumber NVARCHAR(20) NOT NULL,
	ExpMonth INT NOT NULL,
	ExpYear INT NOT NULL,
	CustID INT NOT NULL, -- FK, link to Customers ID
	DateCreated DATETIME NOT NULL CONSTRAINT DF_CreditCards_DateCreated DEFAULT getdate()
);

INSERT INTO CreditCards (CardType, CardNumber, ExpMonth, ExpYear, CustID) VALUES
('Visa', '333360811931', '10', '2025', '300'),
('American Express', '555534656259', '11', '2025', '301'),
('UnionPay', '111197758478', '12', '2025', '302'),
('JCB', '777739716831', '10', '2026', '303'),
('PayPal', '999919854515', '12', '2028', '304'),
('UnionPay', '111122223333', '11', '2027', '300');

SELECT * FROM CreditCards;
-- EXEC sp_help CreditCards;

-- Enforce Referential Integrity Between Two Tables
ALTER TABLE dbo.CreditCards ADD CONSTRAINT FK_CreditCards_Customers
	FOREIGN KEY (CustID) REFERENCES dbo.Customers (CustID) ON DELETE CASCADE ON UPDATE NO ACTION; -- Cascade = when delete sth in customers table, credit cards table will delete also
GO

-- Test Referential Integrity
INSERT INTO Customers (CustName, CustEmail, CustContactNo, CustAddress) VALUES
('TestCust', 'xxx@gmail.com', '0123456789', 'Jalan 123');

INSERT INTO CreditCards (CardType, CardNumber, ExpMonth, ExpYear, CustID) VALUES
('TestCard', '000000000000', '99', '9999', '305');
SELECT * FROM Customers;
SELECT * FROM CreditCards;

-- Test CASCADE
DELETE FROM Customers where CustID = 305
SELECT * FROM Customers;
SELECT * FROM CreditCards;
















/* 
-- Implement ltr if got extra time
-- Create Leave & Leave Types Tables (linked to Employees)
DROP TABLE IF EXISTS LeaveTypes;
DROP TABLE IF EXISTS Leave;

CREATE TABLE LeaveTypes (
   id          INT CONSTRAINT PK_LeaveTypes PRIMARY KEY IDENTITY,
   LeaveType   NVARCHAR(80) NOT NULL,
   LeaveDescr  NVARCHAR(80) NOT NULL,
   DateCreated DATETIME NOT NULL CONSTRAINT DF_LeaveTypes_DateCreated DEFAULT getdate()
);

INSERT INTO LeaveTypes (LeaveType, LeaveDescr) VALUES
('Annual', 'Annual Leave'),
('Study', 'Study Leave'),
('Sick', 'Sick Leave'),
('Unpaid', 'Unpaid Leave')

CREATE TABLE Leave (
   id          INT CONSTRAINT PK_Leave PRIMARY KEY IDENTITY,
   LeaveTypeID INT NOT NULL,
   StartDate   DATE NOT NULL,
   EndDate     DATE NOT NULL,
   LeaveNotes  NVARCHAR(800) NOT NULL,
   EmpID       INT NOT NULL,
   DateCreated DATETIME NOT NULL CONSTRAINT DF_Leave_DateCreated DEFAULT getdate()
);

INSERT INTO Leave (LeaveTypeID, StartDate, EndDate, LeaveNotes, EmpID) VALUES
(1, '2022-09-20', '2022-09-24', 'Annual leave to enjoy vacation at Langkawi', 201)

-- Create FK Relationship
ALTER TABLE dbo.Leave ADD CONSTRAINT FK_Leave_Employees
  FOREIGN KEY(EmpID) REFERENCES Employees(EmpID) ON DELETE NO ACTION ON UPDATE NO ACTION;
  
ALTER TABLE dbo.Leave ADD CONSTRAINT FK_Leave_LeaveTypes
  FOREIGN KEY(LeaveTypeID)REFERENCES LeaveTypes(id) ON DELETE NO ACTION ON UPDATE NO ACTION;

SELECT * FROM LeaveTypes;
SELECT * FROM Leave;
-- EXEC sp_help LeaveTypes;
-- EXEC sp_help Leave; 
*/