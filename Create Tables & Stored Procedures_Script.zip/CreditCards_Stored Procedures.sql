-- Stored Procedure

-- Return a List of All the CreditCards (READ)
USE AsgmtDB;
GO

CREATE OR ALTER PROCEDURE dbo.GetCreditCards
AS
BEGIN
	SELECT CardID, CardType, CardNumber, ExpMonth, ExpYear, CustID, DateCreated
	FROM dbo.CreditCards
END;


--------------------------------------------------------------------------
--                   Separation of Statement Execution                   |
--------------------------------------------------------------------------

-- Insert a New Credit Card (CREATE)
USE AsgmtDB;
GO

CREATE OR ALTER PROCEDURE dbo.InsCreditCard
    @CardType NVARCHAR(50),
    @CardNumber NVARCHAR(20),
    @ExpMonth INT,
    @ExpYear INT,
    @CustID INT
AS
BEGIN
    INSERT INTO dbo.CreditCards
        (CardType, CardNumber, ExpMonth, ExpYear, CustID, DateCreated)
    VALUES
        (@CardType, @CardNumber, @ExpMonth, @ExpYear, @CustID, GETDATE());
END;
 

--------------------------------------------------------------------------
--                   Separation of Statement Execution                   |
--------------------------------------------------------------------------

-- Update Existing Credit Card (UPDATE)
USE AsgmtDB;
GO

CREATE OR ALTER PROCEDURE dbo.UpdCreditCard
    @CardID INT = NULL,
    @CardType NVARCHAR(50) = NULL,
    @CardNumber NVARCHAR(20) = NULL,
    @ExpMonth INT = NULL,
    @ExpYear INT = NULL,
    @CustID INT = NULL
AS
BEGIN
    UPDATE dbo.CreditCards
    SET
        CardType = ISNULL(@CardType, CardType),
        CardNumber = ISNULL(@CardNumber, CardNumber),
        ExpMonth = ISNULL(@ExpMonth, ExpMonth),
        ExpYear = ISNULL(@ExpYear, ExpYear),
        CustID = ISNULL(@CustID, CustID)
    WHERE CardID = @CardID;
END;


--------------------------------------------------------------------------
--                   Separation of Statement Execution                   |
--------------------------------------------------------------------------
-- Delete a Credit Card (DELETE)
USE AsgmtDB;
GO

CREATE OR ALTER PROCEDURE dbo.DelCreditCard
    @CardID INT -- Input parameter
AS
BEGIN
    DELETE FROM dbo.CreditCards
    WHERE CardID = @CardID;
END;


--------------------------------------------------------------------------
--                          Testing the SP                               |
--------------------------------------------------------------------------
-- Test Read All Credit Cards
EXEC dbo.GetCreditCards;

-- Test Read a Single Credit Card
EXEC dbo.GetCreditCard @CardID = 4;

-- Test Insert a New Credit Card
EXEC dbo.InsCreditCard
      @CardType = 'Test Card',
	  @CardNumber = '123456789101',
	  @ExpMonth = '01',
      @ExpYear = '9999',
	  @CustID = '300';

SELECT * FROM dbo.CreditCards;

-- Test Update an Existing Credit Card
dbo.UpdCreditCard
      @CardID       = ?,
	  @CardType     = 'Test Update Card',
      @CardNumber   = '109876543210',
      @ExpMonth   	= 12,
      @ExpYear 		= 2099,
	  @CustID 		= 300
 
SELECT * FROM dbo.CreditCards;

-- Test Delete an Existing Credit Card
EXEC dbo.DelCreditCard
      @CardID = ?;
 
SELECT * FROM dbo.CreditCards;


--------------------------------------------------------------------------
--                   Separation of Statement Execution                   |
--------------------------------------------------------------------------

-- Return a Single Credit Card by ID
USE AsgmtDB;
GO

CREATE OR ALTER PROCEDURE dbo.GetCreditCard
    @CardID INT -- Input parameter
AS
BEGIN
    SELECT CardID, CardType, CardNumber, ExpMonth, ExpYear, CustID, DateCreated
    FROM dbo.CreditCards
    WHERE CardID = @CardID;
END;

--To Execute Stored Procedure you would run the following SQL code:
EXEC dbo.GetCreditCard @CardID = 305;