-- Stored Procedure to Return a List of All the Suppliers (READ)
USE AsgmtDB;
GO
 
CREATE OR ALTER PROCEDURE dbo.GetSuppliers -- CREATE PROCEDURE
AS
BEGIN
      SELECT SupplierID, SupplierName, SupplierContactNo, Address, SupplierEmail, DateCreated
      FROM dbo.Suppliers
END;
 
-- To run the Stored Procedure you would run the following SQL code:
EXEC dbo.GetSuppliers;


--------------------------------------------------------------------------
--                   Separation of Statement Execution                   |
--------------------------------------------------------------------------

-- Stored Procedure to Insert a Single Supplier (CREATE)
USE AsgmtDB;
GO

CREATE OR ALTER PROCEDURE dbo.InsSupplier
	@SupplierName NVARCHAR(100),
    @SupplierContactNo NVARCHAR(20),
    @Address NVARCHAR(80),
    @SupplierEmail NVARCHAR(80)
AS
BEGIN
	INSERT INTO dbo.Suppliers (SupplierName, SupplierContactNo, Address, SupplierEmail, DateCreated)
	VALUES (@SupplierName, @SupplierContactNo, @Address, @SupplierEmail, GETDATE())
END;
 
--To Execute Stored Procedure you would run the following SQL code:
EXEC dbo.InsSupplier
      @SupplierName = 'Test Supplier',
	  @SupplierContactNo = '032345678',
	  @Address = 'Jalan Supplier',
      @SupplierEmail = 'supplier@gmail.com';
 
SELECT * FROM dbo.Suppliers;

--------------------------------------------------------------------------
--                   Separation of Statement Execution                   |
--------------------------------------------------------------------------

-- Stored Procedure to Update a Single Supplier (UPDATE)
USE AsgmtDB;
GO

CREATE OR ALTER PROCEDURE dbo.UpdSupplier
	@SupplierID INT,
	@SupplierName NVARCHAR(100) = NULL,
	@SupplierContactNo NVARCHAR(20) = NULL,
	@Address NVARCHAR(80) = NULL,
	@SupplierEmail NVARCHAR(80) = NULL
AS
BEGIN
	UPDATE dbo.Suppliers
	SET SupplierName = ISNULL(@SupplierName, SupplierName),
		SupplierContactNo = ISNULL(@SupplierContactNo, SupplierContactNo),
		Address = ISNULL(@Address, Address),
		SupplierEmail = ISNULL(@SupplierEmail, SupplierEmail)
	WHERE SupplierID = @SupplierID
END;
 
--To Execute Stored Procedure you would run the following SQL code:
EXEC dbo.UpdSupplier
      @SupplierID		 = 105,
	  @SupplierName		 = 'Test Sdn Bhd',
      @SupplierContactNo = '034567890',
      @Address   = 'Jalan Supplier',
      @SupplierEmail = 'testsp@gmail.com'
 
SELECT * FROM dbo.Suppliers;

--------------------------------------------------------------------------
--                   Separation of Statement Execution                   |
--------------------------------------------------------------------------

-- Stored Procedure to Delete a Single Supplier based on its ID (DELETE)
USE AsgmtDB;
GO

CREATE OR ALTER PROCEDURE dbo.DelSupplier
      @SupplierID  int
AS
BEGIN
      DELETE FROM dbo.Suppliers
      WHERE SupplierID  = @SupplierID 
END;
 
--To Execute Stored Procedure you would run the following SQL code:
EXEC dbo.DelSupplier
      @SupplierID = 105;
 
SELECT * FROM dbo.Suppliers;


--------------------------------------------------------------------------
--                   Separation of Statement Execution                   |
--------------------------------------------------------------------------

-- Stored Procedure to Return a Single Supplier Based on an ID
USE AsgmtDB;
GO

CREATE OR ALTER PROCEDURE dbo.GetSupplier
   @SupplierID int  -- input parameter
AS
BEGIN
      SELECT SupplierID, SupplierName, SupplierContactNo, Address, SupplierEmail, DateCreated
      FROM dbo.Suppliers
      WHERE SupplierID = @SupplierID
END;
 
--To Execute Stored Procedure you would run the following SQL code:
EXEC dbo.GetSupplier @SupplierID = 105;