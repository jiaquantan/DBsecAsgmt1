-- Stored Procedure to Return a List of All the Employees (READ)
USE AsgmtDB;
GO
 
CREATE OR ALTER PROCEDURE dbo.GetEmployees -- CREATE PROCEDURE
AS
BEGIN
      SELECT EmpID, EmpName, EmpEmail, Department, JobTitle, Salary, DateCreated
      FROM dbo.Employees
END;
 
-- To run the Stored Procedure you would run the following SQL code:
EXEC dbo.GetEmployees;

--------------------------------------------------------------------------
--                   Separation of Statement Execution                   |
--------------------------------------------------------------------------

-- Stored Procedure to Insert a Single Employee (CREATE)
USE AsgmtDB;
GO

CREATE OR ALTER PROCEDURE dbo.InsEmployee
	@EmpName NVARCHAR(100),
    @EmpEmail NVARCHAR(80),
    @Department NVARCHAR(50),
    @JobTitle NVARCHAR(50),
    @Salary INT
AS
BEGIN
	INSERT INTO dbo.Employees (EmpName, EmpEmail, Department, JobTitle, Salary, DateCreated)
	VALUES (@EmpName, @EmpEmail, @Department, @JobTitle, @Salary, GETDATE())
END;
 
--To Execute Stored Procedure you would run the following SQL code:
EXEC dbo.InsEmployee
      @EmpName = 'Test EMP',
	  @EmpEmail = 'testemp@gmail.com',
	  @Department = 'TEST',
	  @JobTitle = 'Tester',
      @Salary = 500;
 
SELECT * FROM dbo.Employees;

--------------------------------------------------------------------------
--                   Separation of Statement Execution                   |
--------------------------------------------------------------------------

-- Stored Procedure to Update a Single Employee (UPDATE)
USE AsgmtDB;
GO

CREATE OR ALTER PROCEDURE dbo.UpdEmployee
	@EmpID INT,
    @EmpName NVARCHAR(100) = NULL,
    @EmpEmail NVARCHAR(80) = NULL,
    @Department NVARCHAR(50) = NULL,
    @JobTitle NVARCHAR(50) = NULL,
    @Salary INT = NULL
AS
BEGIN
	UPDATE dbo.Employees
	SET EmpName = ISNULL(@EmpName, EmpName),
        EmpEmail = ISNULL(@EmpEmail, EmpEmail),
        Department = ISNULL(@Department, Department),
        JobTitle = ISNULL(@JobTitle, JobTitle),
        Salary = ISNULL(@Salary, Salary)
	WHERE EmpID = @EmpID
END;
 
--To Execute Stored Procedure you would run the following SQL code:
EXEC dbo.UpdEmployee
      @EmpID		= 210,
	  @EmpName		= 'Test Update Emp',
      @EmpEmail		= 'testsp@gmail.com',
      @Department   = 'test dept',
      @JobTitle = 'test emp',
	  @Salary = 9999
 
SELECT * FROM dbo.Employees;

--------------------------------------------------------------------------
--                   Separation of Statement Execution                   |
--------------------------------------------------------------------------

-- Stored Procedure to Delete a Single Employee based on its ID (DELETE)
USE AsgmtDB;
GO

CREATE OR ALTER PROCEDURE dbo.DelEmployee
      @EmpID int
AS
BEGIN
      DELETE FROM dbo.Employees
      WHERE EmpID = @EmpID
END;
 
--To Execute Stored Procedure you would run the following SQL code:
EXEC dbo.DelEmployee
      @EmpID = 210;
 
SELECT * FROM dbo.Employees;

--------------------------------------------------------------------------
--                   Separation of Statement Execution                   |
--------------------------------------------------------------------------

-- Stored Procedure to Return a Single Employee Based on an ID
USE AsgmtDB;
GO

CREATE OR ALTER PROCEDURE dbo.GetEmployee
   @EmpID int  -- input parameter
AS
BEGIN
      SELECT EmpID, EmpName, EmpEmail, Department, JobTitle, Salary, DateCreated
      FROM dbo.Employees
      WHERE EmpID = @EmpID
END;
 
--To Execute Stored Procedure you would run the following SQL code:
EXEC dbo.GetEmployee @EmpID = 200;